# Política de privacidad de XULFADP

Última actualización: 19 de septiembre de 2026.

## Finalidad

XULFADP permite guardar localmente vídeos, audio y transcripciones que el
usuario ya tiene autorización para reproducir en servicios compatibles.

## Datos

XULFADP no recopila, vende, comparte ni transmite datos personales a servidores
del desarrollador. El procesamiento y la creación de archivos se realizan
localmente en el navegador del usuario.

La extensión puede procesar temporalmente direcciones multimedia, tokens de
sesión y contenido necesario para realizar la descarga solicitada. Esta
información permanece en la sesión del navegador y no se envía a servicios
ajenos a la plataforma que sirve el contenido.

## Almacenamiento local

El permiso `storage` se utiliza exclusivamente para recordar preferencias,
como el formato elegido y el número de descargas paralelas.

## Permisos de sitios

Los permisos sobre dominios de Microsoft Teams y SharePoint son necesarios
para detectar los recursos multimedia y transcripciones que el usuario puede
reproducir. XULFADP no concede acceso a contenido restringido ni evita los
controles de acceso.

## Analítica y publicidad

XULFADP no incorpora analítica, rastreadores, publicidad ni compras.

## Contacto

Antes de publicar, el responsable deberá sustituir esta sección por una
dirección de correo de soporte válida y publicar esta política en una URL
accesible públicamente.
