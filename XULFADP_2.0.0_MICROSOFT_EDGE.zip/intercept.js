(function() {
  const originalFetch = window.fetch;
  function extractHeader(args, headerName) {
    const key = headerName.toLowerCase();
    try {
      if (args[0] && typeof args[0] === 'object' && typeof args[0].headers !== 'undefined' && args[0].headers && typeof args[0].headers.get === 'function') {
        return args[0].headers.get(key);
      }
      const init = args[1];
      if (!init || !init.headers) return null;
      const h = init.headers;
      if (typeof Headers !== 'undefined' && h instanceof Headers) return h.get(key);
      if (Array.isArray(h)) {
        const e = h.find(p => Array.isArray(p) && p[0] && String(p[0]).toLowerCase() === key);
        return e ? e[1] : null;
      }
      if (typeof h === 'object') {
        for (const k of Object.keys(h)) {
          if (k.toLowerCase() === key) return h[k];
        }
      }
    } catch (_) { /* ignore — best-effort capture */ }
    return null;
  }
  function extractSpopActoken(args) { return extractHeader(args, 'x-spopactoken'); }
  function extractAuthorization(args) { return extractHeader(args, 'authorization'); }

  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    const url = args[0];
    if (url && typeof url === 'string' &&
        /\/_api\/v[0-9.]+\//.test(url) &&
        url.includes('sharepoint.com')) {
      const auth = extractAuthorization(args);
      if (auth && /^Bearer\s+/i.test(auth)) {
        window.postMessage({ type: 'SP_API_BEARER', authorization: auth }, '*');
      }
    }
    if (url && typeof url === 'string' &&
        url.includes('transcripts') &&
        !url.includes('/content') &&
        !url.includes('/cdnmedia/')) {
      const clone = response.clone();
      clone.json().then(data => {
        if (!data) return;
        let transcript = null;
        if (data.media && Array.isArray(data.media.transcripts) && data.media.transcripts.length > 0) {
          transcript = data.media.transcripts[0];
        } else if (Array.isArray(data.value) && data.value.length > 0 && data.value[0].temporaryDownloadUrl) {
          transcript = data.value.find(t => t.isDefault) || data.value[0];
        } else if (data.temporaryDownloadUrl) {
          transcript = data;
        }

        if (transcript && transcript.temporaryDownloadUrl) {
          window.postMessage({
            type: 'TRANSCRIPT_METADATA',
            temporaryDownloadUrl: transcript.temporaryDownloadUrl,
            displayName: transcript.displayName,
            languageTag: transcript.languageTag
          }, '*');
        }
      }).catch(err => console.error('[XULFADP] Error parsing transcript metadata from', url, err));
    }
    if (url && typeof url === 'string' && url.includes('videomanifest') &&
        !/tempauth/i.test(url)) {
      let manifestUrl = url;
      const dashIndex = manifestUrl.indexOf('index&format=dash');
      if (dashIndex !== -1) {
        manifestUrl = manifestUrl.substring(0, dashIndex + 'index&format=dash'.length);
      }
      const spopactoken = extractSpopActoken(args);
      console.log('[XULFADP] Detected videomanifest URL:', manifestUrl,
        spopactoken ? '(with x-spopactoken)' : '(no token in request)');
      window.postMessage({
        type: 'VIDEO_MANIFEST_URL',
        manifestUrl: manifestUrl,
        spopactoken: spopactoken
      }, '*');
    }

    return response;
  };
})();
(function() {
  function extractManifestFromFileInfo() {
    if (typeof window.g_fileInfo === 'undefined') return null;

    const transformUrl = window.g_fileInfo['.transformUrl'] || window.g_fileInfo['.providerCdnTransformUrl'];
    if (!transformUrl) return null;

    try {
      const urlObj = new URL(transformUrl);
      urlObj.pathname = urlObj.pathname.replace(/\/transform\/.*$/, '/transform/videomanifest');
      urlObj.searchParams.set('part', 'index');
      urlObj.searchParams.set('format', 'dash');
      return urlObj.toString();
    } catch (e) {
      console.error('[XULFADP] Error constructing manifest URL from g_fileInfo:', e);
      return null;
    }
  }

  function tryPostManifest() {
    const manifestUrl = extractManifestFromFileInfo();
    if (!manifestUrl) return false;
    if (/tempauth/i.test(manifestUrl)) {
      console.debug('[XULFADP] Skipping stale tempauth manifest from g_fileInfo; waiting for fresh URL');
      return false;
    }
    console.log('[XULFADP] Extracted videomanifest from g_fileInfo:', manifestUrl);
    window.postMessage({
      type: 'VIDEO_MANIFEST_URL',
      manifestUrl: manifestUrl
    }, '*');
    return true;
  }
  let transcriptContextPosted = false;
  function tryPostTranscriptContext() {
    if (transcriptContextPosted) return true;
    const g = window.g_fileInfo;
    const spItemUrl = g && g['.spItemUrl'];
    if (!spItemUrl) return false;
    try {
      const u = new URL(spItemUrl);
      const m = u.pathname.match(/^(\/(?:personal|sites)\/[^/]+)\/_api\/v[0-9.]+\/drives\/([^/]+)\/items\/([^/?]+)/);
      if (!m) return false;
      const fileName = g.displayName ||
        (g.name ? g.name.replace(/\.[^.]+$/, '') : null) ||
        g.title || null;
      console.log('[XULFADP] Relaying transcript context from g_fileInfo (hasTranscripts=' + g.hasTranscripts + ')');
      window.postMessage({
        type: 'TRANSCRIPT_CONTEXT',
        sitePath: m[1],
        driveId: m[2],
        itemId: m[3],
        hasTranscripts: g.hasTranscripts,
        fileName: fileName
      }, '*');
      transcriptContextPosted = true;
      return true;
    } catch (e) {
      console.error('[XULFADP] Error parsing g_fileInfo .spItemUrl:', e);
      return false;
    }
  }

  function tryPostAll() {
    return tryPostManifest() & tryPostTranscriptContext() ? true : false;
  }
  if (!tryPostAll()) {
    const originalOnLoad = window.OnLoadVideoFileInfo;
    window.OnLoadVideoFileInfo = function() {
      if (originalOnLoad) originalOnLoad.apply(this, arguments);
      tryPostAll();
    };
    window.addEventListener('load', function() {
      setTimeout(tryPostAll, 1000);
    });
  }
  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'TTD_REQUEST_CONTEXT') {
      transcriptContextPosted = false;
      tryPostTranscriptContext();
      tryPostManifest();
    }
  });
})();
