# Publicación en Microsoft Edge Add-ons

1. Registra una cuenta individual o de empresa en Microsoft Partner Center.
2. Inscríbete en el programa Microsoft Edge Extensions.
3. Crea un nuevo envío de extensión y sube el ZIP preparado.
4. Completa propiedades, disponibilidad, privacidad y notas para certificación.
5. Añade una URL pública para la política de privacidad y un correo de soporte.
6. Adjunta capturas reales y explica cómo acceder a una grabación de prueba.
7. Envía el paquete para certificación.

El programa de extensiones de Microsoft Edge no cobra cuota de registro.

La extensión debe utilizarse únicamente con contenidos que el usuario tenga
autorización para reproducir y guardar. XULFADP es independiente y no está
afiliada, patrocinada ni aprobada por Microsoft.
