
(function() {
  'use strict';

  console.debug('[XULFADP] Content script loaded');

  let transcriptUrl = null;
  let transcriptData = null; // Will store the JSON data
  let vttData = null; // Will store converted VTT
  let selectedFormat = 'vtt'; // Default format (json, vtt, or vtt-grouped)
  let videoManifestUrl = null;
  let videoSpopActoken = null;
  let spApiBearer = null;
  let gFileTranscriptContext = null;
  let videoDownloadConcurrency = 4;
  const VIDEO_CONCURRENCY_OPTIONS = [1, 2, 4, 8, 16];
  const DL_SVG = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5a.75.75 0 0 1 .75.75v6.69l1.97-1.97a.75.75 0 1 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0L4.22 8.03a.75.75 0 1 1 1.06-1.06l1.97 1.97V2.25A.75.75 0 0 1 8 1.5Z M2.75 12a.75.75 0 0 1 .75.75v.75c0 .14.11.25.25.25h8.5a.25.25 0 0 0 .25-.25v-.75a.75.75 0 0 1 1.5 0v.75A1.75 1.75 0 0 1 12.25 15h-8.5A1.75 1.75 0 0 1 2 13.5v-.75a.75.75 0 0 1 .75-.75Z"/></svg>';
  function svcMsFetchInit(extra) {
    const init = Object.assign({}, extra || {});
    if (videoSpopActoken) {
      init.headers = Object.assign({}, init.headers || {}, {
        'x-spopactoken': videoSpopActoken
      });
    }
    return init;
  }
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    if (event.data.type === 'TRANSCRIPT_METADATA') {
      console.log('[XULFADP] Received transcript metadata:', event.data);
      transcriptUrl = event.data.temporaryDownloadUrl;
      updateFloatingWidgetState();
    }

    if (event.data.type === 'TRANSCRIPT_CONTEXT') {
      gFileTranscriptContext = {
        driveId: event.data.driveId || null,
        itemId: event.data.itemId || null,
        sitePath: event.data.sitePath || null,
        hasTranscripts: event.data.hasTranscripts,
        fileName: event.data.fileName || null
      };
      console.debug('[XULFADP] Captured transcript context from g_fileInfo',
        { hasTranscripts: gFileTranscriptContext.hasTranscripts });
      updateFloatingWidgetState();
    }

    if (event.data.type === 'SP_API_BEARER') {
      if (event.data.authorization && event.data.authorization !== spApiBearer) {
        spApiBearer = event.data.authorization;
        console.debug('[XULFADP] Captured SharePoint Stream API bearer');
      }
    }

    if (event.data.type === 'VIDEO_MANIFEST_URL') {
      console.log('[XULFADP] Received video manifest URL:', event.data.manifestUrl,
        event.data.spopactoken ? '(with x-spopactoken)' : '(no token)');
      videoManifestUrl = event.data.manifestUrl;
      if (event.data.spopactoken) videoSpopActoken = event.data.spopactoken;
      updateFloatingWidgetState();
    }
  });

  function timeToSeconds(t) {
    const [h, m, s] = t.split(':');
    return Math.round((parseInt(h) * 3600 + parseInt(m) * 60 + parseFloat(s)) * 1000) / 1000;
  }

  function secondsToVTT(seconds) {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toFixed(3).padStart(6, '0');
    return `${h}:${m}:${s}`;
  }

  function convertJSONToVTT(transcript) {
    const data = JSON.parse(transcript);
    const entries = data.entries || [];
    let vtt = 'WEBVTT\n\n';
    
    entries.forEach((entry, index) => {
      const start = secondsToVTT(timeToSeconds(entry.startOffset));
      const end = secondsToVTT(timeToSeconds(entry.endOffset));
      const speaker = entry.speakerDisplayName || 'Desconocido';
      const text = entry.text || '';
      
      vtt += `${entry.id || index + 1}\n`;
      vtt += `${start} --> ${end}\n`;
      vtt += `<v ${speaker}>${text}\n\n`;
    });
    
    return vtt;
  }
  function convertJSONToGrouped(jsonText) {
    const data = JSON.parse(jsonText);
    const entries = data.entries || [];
    const grouped = [];
    let currentSpeaker = null;
    let bufferText = '';
    
    entries.forEach((entry, i) => {
      const speaker = entry.speakerDisplayName || 'Desconocido';
      const text = entry.text || '';
      
      if (speaker !== currentSpeaker) {
        if (bufferText) {
          grouped.push(`${currentSpeaker}: ${bufferText.trim()}`);
        }
        currentSpeaker = speaker;
        bufferText = text;
      } else {
        bufferText += ' ' + text;
      }
    });
    if (bufferText && currentSpeaker) {
      grouped.push(`${currentSpeaker}: ${bufferText.trim()}`);
    }
    
    return grouped.join('\n\n');
  }
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  function getDefaultBaseName() {
    if (gFileTranscriptContext && gFileTranscriptContext.fileName) {
      return gFileTranscriptContext.fileName;
    }
    return document.title;
  }

  function updateButtonText(format) {
    const modalButton = document.querySelector('#modalDownload');
    if (!modalButton) return;
    
    const formatText = {
      'json': 'Descargar JSON original',
      'vtt': 'Descargar VTT',
      'vtt-grouped': 'Descargar texto agrupado'
    };
    
    modalButton.textContent = formatText[format] || 'Descargar';
  }

  function createFormatSelectionModal() {
    const modal = document.createElement('div');
    modal.id = 'formatSelectionModal';
    const jsonPreview = transcriptData ? escapeHtml(JSON.stringify(JSON.parse(transcriptData), null, 2).substring(0, 500) + '...') : 'Cargando vista previa...';
    const vttPreview = vttData ? escapeHtml(vttData.substring(0, 500) + '...') : 'Cargando vista previa...';
    let groupedPreview = 'Cargando vista previa...';
    if (transcriptData) {
      const grouped = convertJSONToGrouped(transcriptData);
      groupedPreview = escapeHtml(grouped.substring(0, 500) + '...');
    }
    const autoTitle = getDefaultBaseName().replace(/[^a-z0-9\s]/gi, '_').trim();
    const displayTitle = autoTitle || '[Not detected]';
    
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-header">
          <h2>Seleccionar formato de transcripción</h2>
          <button class="modal-close" id="modalClose">&times;</button>
        </div>
        
        <div class="format-options-container">
          <div class="format-option" data-format="json">
            <h3>RAW JSON <span class="format-badge">.json</span></h3>
            <p>Formato original con todos los metadatos</p>
            <div class="format-sample">${jsonPreview}</div>
          </div>
          
          <div class="format-option" data-format="vtt">
            <h3>VTT <span class="format-badge">.vtt</span></h3>
            <p>Subtítulos WebVTT con marcas de tiempo</p>
            <div class="format-sample">${vttPreview}</div>
          </div>
          
          <div class="format-option" data-format="vtt-grouped">
            <h3>Texto agrupado <span class="format-badge">.txt</span></h3>
            <p>Intervenciones consecutivas agrupadas por participante</p>
            <div class="format-sample">${groupedPreview}</div>
          </div>
        </div>
        
        <div class="filename-section">
          <label for="filenameInput" class="filename-label">
            <span class="label-text">Nombre del archivo:</span>
            <span class="auto-detected">(Auto-detected: ${displayTitle})</span>
          </label>
          <div class="filename-input-container">
            <input 
              type="text" 
              id="filenameInput" 
              class="filename-input" 
              placeholder="Enter filename" 
              value="${autoTitle}"
              required
            />
            <span class="filename-suffix" id="filenameSuffix">_transcript</span>
            <span class="filename-extension" id="filenameExtension">.vtt</span>
          </div>
          <div class="filename-hint">Escribe un nombre para la transcripción</div>
        </div>
        
        <div class="modal-actions">
          <div class="modal-actions-buttons">
            <button class="modal-button modal-button-cancel" id="modalCancel">Cancelar</button>
            <button class="modal-button modal-button-download" id="modalDownload">Descargar</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    const options = modal.querySelectorAll('.format-option');
    options.forEach(option => {
      option.addEventListener('click', () => {
        options.forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');
        selectedFormat = option.getAttribute('data-format');
        updateButtonText(selectedFormat);
        updateFilenameSuffix(selectedFormat);
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
          chrome.storage.sync.set({ defaultFormat: selectedFormat });
        }
      });
    });
    function updateFilenameSuffix(format) {
      const suffixSpan = modal.querySelector('#filenameSuffix');
      const extensionSpan = modal.querySelector('#filenameExtension');
      
      if (format === 'json') {
        suffixSpan.textContent = '_transcript';
        extensionSpan.textContent = '.json';
      } else if (format === 'vtt') {
        suffixSpan.textContent = '_transcript';
        extensionSpan.textContent = '.vtt';
      } else if (format === 'vtt-grouped') {
        suffixSpan.textContent = '_transcript_grouped';
        extensionSpan.textContent = '.txt';
      }
    }
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(['defaultFormat'], (result) => {
        const defaultFormat = result.defaultFormat || 'vtt-grouped';
        selectedFormat = defaultFormat;
        modal.querySelector(`[data-format="${defaultFormat}"]`)?.classList.add('selected');
        updateButtonText(defaultFormat);
        updateFilenameSuffix(defaultFormat);
      });
    } else {
      selectedFormat = 'vtt-grouped';
      modal.querySelector('[data-format="vtt-grouped"]')?.classList.add('selected');
      updateButtonText('vtt-grouped');
      updateFilenameSuffix('vtt-grouped');
    }
    
    document.getElementById('modalClose').addEventListener('click', () => {
      modal.classList.remove('show');
    });
    
    document.getElementById('modalCancel').addEventListener('click', () => {
      modal.classList.remove('show');
    });
    
    document.getElementById('modalDownload').addEventListener('click', () => {
      const filenameInput = modal.querySelector('#filenameInput');
      const filename = filenameInput.value.trim();
      
      if (!filename) {
        filenameInput.classList.add('error');
        alert('Introduce un nombre de archivo');
        return;
      }
      
      filenameInput.classList.remove('error');
      modal.classList.remove('show');
      proceedWithDownload(filename);
    });
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('show');
      }
    });
  }

  function showFormatModal() {
    let modal = document.getElementById('formatSelectionModal');
    if (!modal) {
      createFormatSelectionModal();
      modal = document.getElementById('formatSelectionModal');
    }
    modal.classList.add('show');
  }
  function injectDownloadButton() {
    const disabledButton = document.querySelector('#downloadTranscript');
    
    if (!disabledButton) {
      return false;
    }
    if (document.querySelector('#customDownloadTranscript')) {
      return true;
    }

    console.debug('[XULFADP] Injecting custom download button');
    if (!document.querySelector('#transcript-downloader-styles')) {
      const style = document.createElement('style');
      style.id = 'transcript-downloader-styles';
      style.textContent = `
        #downloadTranscript {
          display: none !important;
        }
        
        #customDownloadTranscript {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
          color: white !important;
          border: none !important;
          transition: background 0.3s ease !important;
          cursor: pointer !important;
        }
        
        #customDownloadTranscript:hover {
          background: linear-gradient(135deg, #764ba2 0%, #667eea 100%) !important;
          cursor: pointer !important;
        }
        
        #customDownloadTranscript:active {
          box-shadow: 0 2px 4px rgba(102, 126, 234, 0.4) !important;
        }
        
        #customDownloadTranscript .ms-Button-icon {
          color: white !important;
        }
        
        #customDownloadTranscript .ms-Button-label {
          color: white !important;
          font-weight: 600 !important;
        }
        
        #customDownloadTranscript .ms-Button-menuIcon {
          color: white !important;
        }
      `;
      document.head.appendChild(style);
    }
    const parentContainer = disabledButton.closest('.ms-OverflowSet-item');
    
    if (!parentContainer || !parentContainer.parentElement) {
      console.error('[XULFADP] Could not find parent container');
      return false;
    }
    const newButtonContainer = parentContainer.cloneNode(true);
    const newButton = newButtonContainer.querySelector('button');
    
    if (!newButton) {
      console.error('[XULFADP] Could not create button');
      return false;
    }
    newButton.id = 'customDownloadTranscript';
    newButton.classList.remove('is-disabled');
    newButton.setAttribute('aria-disabled', 'false');
    newButton.setAttribute('aria-label', 'Descargar transcripción');
    const labelSpan = newButton.querySelector('.ms-Button-label');
    if (labelSpan) {
      labelSpan.textContent = 'Descargar transcripción';
    }
    const tooltip = newButtonContainer.querySelector('#transcriptDownloadDisableTooltip');
    if (tooltip) {
      tooltip.remove();
    }
    const screenReaderText = newButton.querySelector('.ms-Button-screenReaderText');
    if (screenReaderText) {
      screenReaderText.textContent = 'Descargar transcripción';
    }
    newButton.addEventListener('click', handleDownloadClick);
    parentContainer.parentElement.insertBefore(newButtonContainer, parentContainer.nextSibling);

    console.debug('[XULFADP] Custom button injected successfully');
    return true;
  }
  function deriveTranscriptContext() {
    let driveId = null, itemId = null, sitePath = null;
    if (videoManifestUrl) {
      try {
        const docidRaw = new URL(videoManifestUrl).searchParams.get('docid');
        if (docidRaw) {
          const docUrl = new URL(decodeURIComponent(docidRaw));
          const m = docUrl.pathname.match(/^(\/(?:personal|sites)\/[^/]+)\/_api\/v[0-9.]+\/drives\/([^/]+)\/items\/([^/?]+)/);
          if (m) { sitePath = m[1]; driveId = m[2]; itemId = m[3]; }
        }
      } catch (_) { /* ignore */ }
    }
    if ((!driveId || !itemId || !sitePath) && gFileTranscriptContext) {
      if (!driveId) driveId = gFileTranscriptContext.driveId || null;
      if (!itemId) itemId = gFileTranscriptContext.itemId || null;
      if (!sitePath) sitePath = gFileTranscriptContext.sitePath || null;
    }
    if (!sitePath) {
      const m = window.location.pathname.match(/^\/(?:personal|sites)\/[^/]+/);
      if (m) sitePath = m[0];
    }

    return { driveId, itemId, sitePath };
  }
  function requestTranscriptContext() {
    try { window.postMessage({ type: 'TTD_REQUEST_CONTEXT' }, '*'); } catch (_) { /* ignore */ }
  }
  function waitForTranscriptContext(timeoutMs) {
    return new Promise((resolve) => {
      const haveIt = () => !!(gFileTranscriptContext && gFileTranscriptContext.driveId && gFileTranscriptContext.itemId);
      if (haveIt()) { resolve(true); return; }
      requestTranscriptContext();
      const start = Date.now();
      const iv = setInterval(() => {
        if (haveIt() || Date.now() - start > timeoutMs) {
          clearInterval(iv);
          resolve(haveIt());
        }
      }, 100);
    });
  }
  async function fetchTranscriptUrl() {
    if (!videoManifestUrl && !(gFileTranscriptContext && gFileTranscriptContext.driveId)) {
      await waitForTranscriptContext(1500);
    }
    if (gFileTranscriptContext && gFileTranscriptContext.hasTranscripts === false) {
      console.debug('[XULFADP] g_fileInfo reports hasTranscripts=false');
      return { status: 'none' };
    }

    const { driveId, itemId, sitePath } = deriveTranscriptContext();
    if (!driveId || !itemId || !sitePath) {
      console.warn('[XULFADP] Cannot proactively fetch transcript metadata — missing context', { driveId, itemId, sitePath });
      return { status: 'unknown' };
    }
    const baseUrl = `${window.location.origin}${sitePath}/_api/v2.1/drives/${driveId}/items/${itemId}`;
    const expandUrl = `${baseUrl}?select=media%2Ftranscripts%2CaudioTracks&%24expand=media%2Ftranscripts%2Cmedia%2FaudioTracks`;
    const collectionUrl = `${baseUrl}/media/transcripts`;

    const headers = { 'Accept': 'application/json' };
    if (spApiBearer) headers['Authorization'] = spApiBearer;

    console.log('[XULFADP] Proactively fetching transcript metadata:', expandUrl,
      spApiBearer ? '(with bearer)' : '(cookie auth only)');

    let resp = await fetch(expandUrl, { credentials: 'include', headers });
    if (!resp.ok) {
      console.debug('[XULFADP] Expand call failed, falling back to collection endpoint');
      resp = await fetch(collectionUrl, { credentials: 'include', headers });
    }
    if (!resp.ok) {
      console.error('[XULFADP] Metadata fetch failed:', resp.status, resp.statusText);
      return { status: 'unknown' };
    }
    const data = await resp.json();

    let transcript = null;
    if (data && data.media && Array.isArray(data.media.transcripts) && data.media.transcripts.length > 0) {
      transcript = data.media.transcripts[0];
    } else if (data && Array.isArray(data.value) && data.value.length > 0 && data.value[0].temporaryDownloadUrl) {
      transcript = data.value.find(t => t.isDefault) || data.value[0];
    } else if (data && data.temporaryDownloadUrl) {
      transcript = data;
    }

    if (transcript && transcript.temporaryDownloadUrl) {
      transcriptUrl = transcript.temporaryDownloadUrl;
      updateFloatingWidgetState();
      return { status: 'ok', url: transcriptUrl };
    }
    const definitivelyEmpty =
      (data && data.media && (
        !Array.isArray(data.media.transcripts) ||
        data.media.transcripts.length === 0
      )) ||
      (data && Array.isArray(data.value) && data.value.length === 0);

    console.warn('[XULFADP] Metadata response had no temporaryDownloadUrl', data);
    return { status: definitivelyEmpty ? 'none' : 'unknown' };
  }
  async function handleDownloadClick(event) {
    event.preventDefault();
    event.stopPropagation();

    console.log('[XULFADP] Download button clicked');
    let fetchResult = null;
    if (!transcriptUrl) {
      try {
        fetchResult = await fetchTranscriptUrl();
      } catch (e) {
        console.error('[XULFADP] Proactive metadata fetch errored:', e);
      }
    }
    if (!transcriptUrl) {
      const status = (fetchResult && fetchResult.status) || 'unknown';
      console.error('[XULFADP] No transcript URL available; status:', status);
      showNoTranscriptWarning(status);
      return;
    }

    try {
      let jsonUrl = transcriptUrl.includes('?')
        ? `${transcriptUrl}&format=json`
        : `${transcriptUrl}?format=json`;
      try {
        const parsedUrl = new URL(jsonUrl);

        if (
          window.location.hostname.endsWith('.sharepoint.com.mcas.ms') &&
          parsedUrl.hostname.endsWith('.sharepoint.com')
        ) {
          parsedUrl.hostname = `${parsedUrl.hostname}.mcas.ms`;
          jsonUrl = parsedUrl.href;

          console.debug(
            '[XULFADP] Rewriting transcript URL through MCAS:',
            jsonUrl
          );
        }
      } catch (e) {
        console.warn(
          '[XULFADP] Failed to rewrite transcript URL:',
          e
        );
      }

      console.debug('[XULFADP] Fetching JSON from:', jsonUrl);

      const jsonResponse = await fetch(jsonUrl);
      if (!jsonResponse.ok) {
        throw new Error(`HTTP ${jsonResponse.status}: ${jsonResponse.statusText}`);
      }
      
      transcriptData = await jsonResponse.text();
      console.log('[XULFADP] JSON data fetched successfully');
      vttData = convertJSONToVTT(transcriptData);
      console.debug('[XULFADP] VTT conversion complete');
      showFormatModal();
      
    } catch (error) {
      console.error('[XULFADP] Error al descargar la transcripción:', error);
      alert('Error al descargar la transcripción: ' + error.message);
    }
  }
  function proceedWithDownload(customFilename) {
    if (!transcriptData) {
      alert('No hay datos de transcripción disponibles');
      return;
    }

    let outputData = transcriptData; // JSON by default
    let extension = '.json';
    let suffix = '_transcript';
    if (selectedFormat === 'vtt') {
      outputData = vttData;
      extension = '.vtt';
      suffix = '_transcript';
    } else if (selectedFormat === 'vtt-grouped') {
      outputData = convertJSONToGrouped(transcriptData);
      extension = '.txt';
      suffix = '_transcript_grouped';
    }
    const sanitizedFilename = customFilename.replace(/[^a-z0-9\s]/gi, '_').toLowerCase();
    const filename = `${sanitizedFilename}${suffix}${extension}`;
    downloadDecryptedFile(outputData, filename);
    console.debug('[XULFADP] Descarga completada!');
  }
  function downloadDecryptedFile(data, filename) {
    const mimeTypes = {
      '.json': 'application/json',
      '.vtt': 'text/vtt',
      '.txt': 'text/plain'
    };
    const ext = filename.substring(filename.lastIndexOf('.'));
    const mimeType = mimeTypes[ext] || 'text/plain';

    const blob = new Blob(Array.isArray(data) ? data : [data], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    console.debug('[XULFADP] File downloaded successfully:', filename);
  }

  function parseDashManifest(xmlText, manifestUrl) {
    const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
    if (doc.querySelector('parsererror')) {
      throw new Error('Failed to parse DASH manifest XML');
    }
    const baseUrlEl = doc.querySelector('BaseURL');
    const manifestDerivedBase = manifestUrl.split('?')[0].replace(/\/[^/]*$/, '/');
    const baseUrl = (baseUrlEl && baseUrlEl.textContent.trim()) || manifestDerivedBase;

    function toAbsolute(url) {
      if (!url) return '';
      if (/^https:\/\//.test(url)) return url;
      if (/^[a-z][a-z0-9+\-.]*:/i.test(url)) throw new Error('Unsafe URL scheme in manifest: ' + url);
      return new URL(url, baseUrl).href;
    }

    function expandTemplate(tpl, repId, bandwidth, number, time) {
      return tpl
        .replace(/\$RepresentationID\$/g, repId)
        .replace(/\$Bandwidth\$/g, bandwidth)
        .replace(/\$Number%0(\d+)d\$/g, (_, w) => String(number).padStart(parseInt(w, 10), '0'))
        .replace(/\$Number\$/g, String(number))
        .replace(/\$Time\$/g, String(time));
    }

    const adaptationSets = Array.from(doc.querySelectorAll('AdaptationSet'));
    const isMuxed = adaptationSets.length === 1;
    const tracks = [];

    for (const as of adaptationSets) {
      let type = as.getAttribute('contentType') || '';
      if (!type) {
        const mime = as.getAttribute('mimeType') || '';
        type = mime.startsWith('video') ? 'video' : mime.startsWith('audio') ? 'audio' : '';
      }
      if (isMuxed) type = 'muxed';

      const reps = Array.from(as.querySelectorAll('Representation'))
        .sort((a, b) => parseInt(b.getAttribute('bandwidth') || '0', 10) - parseInt(a.getAttribute('bandwidth') || '0', 10));
      const rep = reps[0];
      if (!rep) continue;

      const repId = rep.getAttribute('id') || '';
      const bandwidth = rep.getAttribute('bandwidth') || '';
      const mimeType = rep.getAttribute('mimeType') || as.getAttribute('mimeType') || '';

      const segTpl = rep.querySelector('SegmentTemplate') || as.querySelector('SegmentTemplate');
      if (!segTpl) continue;

      const startNumber = parseInt(segTpl.getAttribute('startNumber') || '1', 10);
      const initTpl = segTpl.getAttribute('initialization') || '';
      const mediaTpl = segTpl.getAttribute('media') || '';
      const initUrl = toAbsolute(expandTemplate(initTpl, repId, bandwidth, startNumber, 0));
      const segments = [];

      const timeline = segTpl.querySelector('SegmentTimeline');
      if (timeline) {
        let t = 0, segNum = startNumber;
        for (const s of timeline.querySelectorAll('S')) {
          const sT = s.getAttribute('t');
          if (sT !== null) t = parseInt(sT, 10);
          const d = parseInt(s.getAttribute('d') || '0', 10);
          const r = parseInt(s.getAttribute('r') || '0', 10);
          for (let i = 0; i <= r; i++) {
            segments.push(toAbsolute(expandTemplate(mediaTpl, repId, bandwidth, segNum, t)));
            t += d;
            segNum++;
          }
        }
      } else {
        const duration = parseInt(segTpl.getAttribute('duration') || '0', 10);
        const timescale = parseInt(segTpl.getAttribute('timescale') || '1', 10);
        const period = as.closest('Period');
        const periodDur = period ? (() => {
          const m = (period.getAttribute('duration') || '').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?/);
          return m ? parseInt(m[1] || '0') * 3600 + parseInt(m[2] || '0') * 60 + parseFloat(m[3] || '0') : 0;
        })() : 0;
        if (duration > 0 && periodDur > 0) {
          const count = Math.ceil(periodDur / (duration / timescale));
          for (let i = 0; i < count; i++) {
            segments.push(toAbsolute(expandTemplate(mediaTpl, repId, bandwidth, startNumber + i, i * duration)));
          }
        }
      }
      let encryption = null;
      const seaCp = [...as.querySelectorAll('ContentProtection')].find(cp =>
        cp.getAttribute('schemeIdUri') === 'urn:mpeg:dash:sea:2012'
      );
      if (seaCp) {
        const segEnc = seaCp.querySelector('SegmentEncryption');
        const scheme = segEnc ? segEnc.getAttribute('schemeIdUri') : '';
        const period = seaCp.querySelector('CryptoPeriod');
        const keyUri = period ? period.getAttribute('keyUriTemplate') : null;
        const ivAttr = period ? (period.getAttribute('IV') || '') : '';
        if (/aes128-cbc/i.test(scheme) && keyUri && ivAttr) {
          encryption = {
            scheme: 'aes-128-cbc',
            keyUri,
            iv: hexToBytes(ivAttr.replace(/^0x/i, ''))
          };
        }
      }

      tracks.push({ type, mimeType, initUrl, segments, encryption });
    }

    return tracks;
  }

  function hexToBytes(hex) {
    const out = new Uint8Array(hex.length / 2);
    for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }
  function abortableSleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal && signal.aborted) {
        reject(Object.assign(new Error('Cancelled'), { name: 'AbortError' }));
        return;
      }
      const t = setTimeout(() => {
        if (signal) signal.removeEventListener('abort', onAbort);
        resolve();
      }, ms);
      function onAbort() {
        clearTimeout(t);
        reject(Object.assign(new Error('Cancelled'), { name: 'AbortError' }));
      }
      if (signal) signal.addEventListener('abort', onAbort, { once: true });
    });
  }
  function isRetriableStatus(status) {
    return status === 408 || status === 409 || status === 429 || (status >= 500 && status <= 599);
  }
  async function fetchWithRetry(url, init, signal, onThrottle, maxAttempts = 8) {
    let attempt = 0;
    for (;;) {
      attempt++;
      if (signal && signal.aborted) {
        throw Object.assign(new Error('Cancelled'), { name: 'AbortError' });
      }
      let resp;
      try {
        resp = await fetch(url, init);
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        if (attempt >= maxAttempts) throw e;
        const delayMs = Math.min(1000 * Math.pow(2, attempt - 1), 30000);
        if (onThrottle) onThrottle({ attempt, delayMs, status: 0 });
        await abortableSleep(delayMs, signal);
        continue;
      }
      if (isRetriableStatus(resp.status) && attempt < maxAttempts) {
        const headerSecs = parseInt(resp.headers.get('Retry-After'), 10);
        const delayMs = Number.isFinite(headerSecs) && headerSecs > 0
          ? Math.min(headerSecs * 1000, 30000)
          : Math.min(1000 * Math.pow(2, attempt - 1), 30000);
        if (onThrottle) onThrottle({ attempt, delayMs, status: resp.status });
        await abortableSleep(delayMs, signal);
        continue;
      }
      return resp;
    }
  }
  function segmentFailureMessage(what, status, url) {
    const suffix = url ? ` for ${url}` : '';
    if (isRetriableStatus(status)) {
      return `${what} failed after repeated retries: HTTP ${status}${suffix}. ` +
        `The server returned a temporary error — this usually clears in a few minutes, so wait and try the download again.`;
    }
    return `${what} failed: HTTP ${status}${suffix}`;
  }

  async function downloadDashSegments(tracks, onProgress, signal) {
    const concurrency = videoDownloadConcurrency;

    const totalSegs = tracks.reduce((s, t) => s + (t.initUrl ? 1 : 0) + t.segments.length, 0);
    let done = 0;
    let lastThrottleStatus = null;

    function reportProgress(text) { onProgress(done, totalSegs, text); }
    function noteThrottle({ attempt, delayMs, status }) {
      lastThrottleStatus = `HTTP ${status || 'network'} — backing off ${Math.round(delayMs / 1000)}s (attempt ${attempt})...`;
      reportProgress(lastThrottleStatus);
    }
    const trackStates = await Promise.all(tracks.map(async (track) => {
      const label = tracks.length > 1 ? ` (${track.type} track)` : '';
      let cryptoKey = null;
      if (track.encryption) {
        reportProgress(`Fetching encryption key${label}...`);
        const init = track.encryption.keyUri.includes('svc.ms') && videoSpopActoken
          ? { signal, headers: { 'x-spopactoken': videoSpopActoken } }
          : { signal };
        const keyResp = await fetchWithRetry(track.encryption.keyUri, init, signal, noteThrottle);
        if (!keyResp.ok) throw new Error(segmentFailureMessage('Encryption key fetch', keyResp.status));
        const keyBuf = await keyResp.arrayBuffer();
        cryptoKey = await crypto.subtle.importKey('raw', keyBuf, { name: 'AES-CBC' }, false, ['decrypt']);
      }

      async function decryptIfNeeded(buf) {
        if (!cryptoKey) return buf;
        return await crypto.subtle.decrypt({ name: 'AES-CBC', iv: track.encryption.iv }, cryptoKey, buf);
      }
      const orderedBufs = new Array((track.initUrl ? 1 : 0) + track.segments.length);
      let segStart = 0;
      if (track.initUrl) {
        reportProgress(`Fetching init segment${label}...`);
        const r = await fetchWithRetry(track.initUrl, { signal }, signal, noteThrottle);
        if (!r.ok) throw new Error(segmentFailureMessage('Init segment', r.status, track.initUrl));
        orderedBufs[0] = await decryptIfNeeded(await r.arrayBuffer());
        done++;
        segStart = 1;
      }

      return { track, label, orderedBufs, segStart, decryptIfNeeded };
    }));
    const queue = [];
    for (const st of trackStates) {
      for (let si = 0; si < st.track.segments.length; si++) queue.push({ st, si });
    }
    reportProgress(`Descargando ${queue.length} segmentos (${concurrency} simultáneos)...`);

    await new Promise((resolve, reject) => {
      if (queue.length === 0) { resolve(); return; }
      let qIdx = 0, inFlight = 0;
      let rejected = false;

      function launch() {
        while (!rejected && inFlight < concurrency && qIdx < queue.length) {
          if (signal && signal.aborted) {
            rejected = true;
            reject(Object.assign(new Error('Cancelled'), { name: 'AbortError' }));
            return;
          }
          const job = queue[qIdx++];
          inFlight++;
          fetchWithRetry(job.st.track.segments[job.si], { signal }, signal, noteThrottle)
            .then(r => {
              if (!r.ok) throw new Error(segmentFailureMessage('Segment', r.status, job.st.track.segments[job.si]));
              return r.arrayBuffer();
            })
            .then(job.st.decryptIfNeeded)
            .then(buf => {
              if (rejected) return;
              job.st.orderedBufs[job.st.segStart + job.si] = buf;
              done++;
              reportProgress(`Descargando segmentos... (${done}/${totalSegs})`);
              inFlight--;
              if (inFlight === 0 && qIdx >= queue.length) resolve();
              else launch();
            })
            .catch(err => {
              if (rejected) return;
              rejected = true;
              reject(err);
            });
        }
      }
      launch();
    });

    return trackStates.map(s => s.orderedBufs);
  }
  let _muxWorkerBlobUrl = null;
  async function getMuxWorkerUrl() {
    if (_muxWorkerBlobUrl) return _muxWorkerBlobUrl;
    const resp = await fetch(chrome.runtime.getURL('mux-worker.js'));
    if (!resp.ok) throw new Error(`mux-worker fetch failed: HTTP ${resp.status}`);
    const src = await resp.text();
    _muxWorkerBlobUrl = URL.createObjectURL(new Blob([src], { type: 'application/javascript' }));
    return _muxWorkerBlobUrl;
  }
  let _transferablesSupported = null;

  function isArrayBufferLike(b) {
    return b != null && Object.prototype.toString.call(b) === '[object ArrayBuffer]';
  }

  function normalizeToArrayBuffer(b) {
    if (b == null) return null;
    if (isArrayBufferLike(b)) return b;
    if (ArrayBuffer.isView(b)) return b.buffer;
    return null;
  }

  function buildTransferList(arrays) {
    const list = [];
    const seen = new Set();
    const skipped = { nullish: 0, nonObject: 0, nonArrayBuffer: 0, duplicate: 0, skippedSamples: [] };
    let total = 0;
    for (const arr of arrays) {
      for (const b of arr) {
        total++;
        if (b == null) { skipped.nullish++; if (skipped.skippedSamples.length < 3) skipped.skippedSamples.push(typeof b); continue; }
        if (typeof b !== 'object') { skipped.nonObject++; if (skipped.skippedSamples.length < 3) skipped.skippedSamples.push(typeof b); continue; }
        const ab = normalizeToArrayBuffer(b);
        if (!isArrayBufferLike(ab)) { skipped.nonArrayBuffer++; if (skipped.skippedSamples.length < 3) skipped.skippedSamples.push((b && b.constructor && b.constructor.name) || typeof b); continue; }
        if (seen.has(ab)) { skipped.duplicate++; continue; }
        seen.add(ab);
        list.push(ab);
      }
    }
    return { list, total, skipped };
  }

  let _muxPathLogged = false;
  function postChunksToWorker(worker, videoChunks, audioChunks) {
    if (_transferablesSupported !== false) {
      try {
        const videoBufs = videoChunks.map(normalizeToArrayBuffer);
        const audioBufs = audioChunks.map(normalizeToArrayBuffer);
        const built = buildTransferList([videoBufs, audioBufs]);
        if (built.skipped.nullish || built.skipped.nonObject || built.skipped.nonArrayBuffer || built.skipped.duplicate) {
          console.warn('[XULFADP] mux transfer list had non-ArrayBuffer entries filtered out:', {
            total: built.total,
            transferred: built.list.length,
            ...built.skipped
          });
        }
        worker.postMessage({ video: videoBufs, audio: audioBufs }, built.list);
        if (!_muxPathLogged) {
          console.log('[XULFADP] mux: using transferables path (' + built.list.length + ' buffers transferred)');
          _muxPathLogged = true;
        }
        _transferablesSupported = true;
        return;
      } catch (e) {
        console.warn('[XULFADP] mux: transferables path threw, falling back to structured clone:', e && (e.message || e));
        _transferablesSupported = false;
      }
    }

    const videoBufs = videoChunks.map(b => b.slice(0));
    const audioBufs = audioChunks.map(b => b.slice(0));
    worker.postMessage({ video: videoBufs, audio: audioBufs });
    if (!_muxPathLogged) {
      console.log('[XULFADP] mux: using structured-clone path (' + (videoBufs.length + audioBufs.length) + ' buffers copied)');
      _muxPathLogged = true;
    }
  }

  async function muxTracks(videoChunks, audioChunks, onProgress) {
    const workerUrl = await getMuxWorkerUrl();
    return await new Promise((resolve, reject) => {
      const worker = new Worker(workerUrl);
      worker.onmessage = (event) => {
        const msg = event.data;
        if (msg.progress) {
          onProgress(msg.progress.done, msg.progress.total, msg.progress.text);
        } else if (msg.error) {
          worker.terminate();
          reject(new Error(msg.error));
        } else if (msg.result) {
          worker.terminate();
          resolve(msg.result);
        }
      };
      worker.onerror = (e) => {
        worker.terminate();
        reject(new Error(e.message || 'mux-worker crashed'));
      };

      try {
        postChunksToWorker(worker, videoChunks, audioChunks);
      } catch (error) {
        worker.terminate();
        reject(error);
      }
    });
  }


  async function triggerBrowserVideoDownload(format, filename, onProgress, signal) {
    onProgress(0, 1, 'Obteniendo manifiesto...');
    const resp = await fetch(videoManifestUrl, svcMsFetchInit({ signal }));
    if (!resp.ok) throw new Error(`Manifest fetch failed: HTTP ${resp.status}`);
    const xmlText = await resp.text();

    onProgress(0, 1, 'Analizando manifiesto...');
    const allTracks = parseDashManifest(xmlText, videoManifestUrl);
    if (!allTracks.length) throw new Error('No tracks found in manifest');
    const HARD_DRM_SCHEMES = [
      'edef8ba9-79d6-4ace-a3c8-27dcd51d21ed', // Widevine
      '9a04f079-9840-4286-ab92-e65be0885f95', // PlayReady
      '94ce86fb-07ff-4f43-adb8-93d2fa968ca2'  // FairPlay
    ];
    const cpSchemes = [...xmlText.matchAll(/<ContentProtection\b[^>]*schemeIdUri="([^"]+)"/gi)]
      .map(m => m[1].toLowerCase());
    const hasHardDrm = cpSchemes.some(s =>
      HARD_DRM_SCHEMES.some(uuid => s.includes(uuid))
    );
    if (hasHardDrm) {
      const err = new Error('DRM_PROTECTED');
      err.isDrm = true;
      throw err;
    }

    const videoTrack = allTracks.find(t => t.type === 'video' || t.type === 'muxed');
    const audioTrack = allTracks.find(t => t.type === 'audio');

    let tracksToDownload, isSeparate = false;

    if (format === 'video-audio') {
      if (!audioTrack || allTracks.length === 1) {
        tracksToDownload = [videoTrack || allTracks[0]];
      } else {
        tracksToDownload = [videoTrack, audioTrack].filter(Boolean);
        isSeparate = tracksToDownload.length > 1;
      }
    } else if (format === 'audio-m4a') {
      tracksToDownload = [audioTrack || allTracks[0]];
    } else if (format === 'video-only') {
      tracksToDownload = [videoTrack || allTracks[0]];
    } else {
      throw new Error('Format not supported for browser download: ' + format);
    }

    const safeFilename = filename.replace(/[^a-z0-9\s_-]/gi, '_');
    const trackData = await downloadDashSegments(tracksToDownload, onProgress, signal);

    if (isSeparate) {
      const muxed = await muxTracks(trackData[0], trackData[1], onProgress);
      downloadDecryptedFile(muxed, safeFilename + '.mp4');
      onProgress(1, 1, 'Descarga completada!');
    } else {
      const ext = format === 'audio-m4a' ? '.m4a' : '.mp4';
      downloadDecryptedFile(trackData[0], safeFilename + ext);
      onProgress(1, 1, 'Descarga completada!');
    }
  }
  function showDrmWarning() {
    let overlay = document.getElementById('ttdDrmWarningOverlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'ttdDrmWarningOverlay';
      overlay.innerHTML = `
        <div class="ttd-drm-dialog" role="alertdialog" aria-labelledby="ttdDrmTitle">
          <div class="ttd-drm-icon" aria-hidden="true">&#128274;</div>
          <h2 id="ttdDrmTitle">Este vídeo está protegido con DRM</h2>
          <p>El contenido está cifrado y solo puede reproducirse mediante el módulo DRM integrado en el navegador.</p>
          <p><strong>No puede descargarse</strong> mediante esta extensión ni mediante otras herramientas ejecutadas por el usuario.</p>
          <p>Solicita al propietario una copia sin protección si necesitas guardar el vídeo.</p>
          <div class="ttd-drm-actions">
            <button type="button" id="ttdDrmDismiss">OK</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      const dismiss = () => overlay.classList.remove('show');
      overlay.querySelector('#ttdDrmDismiss').addEventListener('click', dismiss);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) dismiss(); });
    }
    overlay.classList.add('show');
  }
  function showNoTranscriptWarning(status) {
    let overlay = document.getElementById('ttdNoTranscriptOverlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'ttdNoTranscriptOverlay';
      overlay.innerHTML = `
        <div class="ttd-info-dialog" role="alertdialog" aria-labelledby="ttdNoTxTitle">
          <div class="ttd-info-icon" aria-hidden="true">&#128172;</div>
          <h2 id="ttdNoTxTitle"></h2>
          <div id="ttdNoTxBody"></div>
          <div class="ttd-info-actions">
            <button type="button" id="ttdNoTxDismiss">OK</button>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);
      const dismiss = () => overlay.classList.remove('show');
      overlay.querySelector('#ttdNoTxDismiss').addEventListener('click', dismiss);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) dismiss(); });
    }

    const title = overlay.querySelector('#ttdNoTxTitle');
    const body = overlay.querySelector('#ttdNoTxBody');
    if (status === 'none') {
      title.textContent = 'Esta grabación no tiene transcripción';
      body.innerHTML =
        '<p>El servicio confirma que <strong>no se generó ninguna transcripción</strong> para esta grabación.</p>' +
        '<p>Motivos habituales:</p>' +
        '<p>&bull; El organizador no activó la transcripción antes de comenzar.<br>' +
        '&bull; La grabación es reciente y la transcripción sigue procesándose.<br>' +
        '&bull; El archivo es un vídeo normal y nunca se generó una transcripción para él.</p>' +
        '<p>No hay ninguna transcripción que descargar.</p>';
    } else {
      title.textContent = 'No se ha encontrado una transcripción';
      body.innerHTML =
        '<p>No hemos podido confirmar si el vídeo dispone de transcripción.</p>' +
        '<p>Abre el panel de <strong>Transcripción</strong> del vídeo y vuelve a pulsar Descargar transcripción.</p>' +
        '<p>Si el panel no existe o está vacío, no hay ninguna transcripción disponible.</p>';
    }
    overlay.classList.add('show');
  }

  function injectFloatingWidget() {
    if (document.getElementById('ttdFloatingWidget')) return true;
    if (!document.body) return false;

    if (!document.querySelector('#ttd-floating-styles')) {
      const style = document.createElement('style');
      style.id = 'ttd-floating-styles';
      style.textContent = `
        #ttdFloatingWidget {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 2147483600;
          display: flex;
          flex-direction: row;
          justify-content: flex-end;
          gap: 8px;
          padding: 6px 16px;
          background: rgba(28, 28, 30, 0.92);
          backdrop-filter: blur(8px);
          -webkit-backdrop-filter: blur(8px);
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        .ttd-floating-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 6px 14px 6px 10px;
          border-radius: 6px;
          border: 1px solid rgba(255,255,255,0.25);
          color: #fff;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.2px;
          cursor: pointer;
          box-shadow: 0 1px 2px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.18);
          transition: transform 0.12s ease, filter 0.12s ease, opacity 0.15s ease, box-shadow 0.12s ease;
          line-height: 1.2;
          height: 30px;
          text-shadow: 0 1px 1px rgba(0,0,0,0.15);
        }
        .ttd-floating-btn:hover {
          transform: translateY(-1px);
          filter: brightness(1.06);
          box-shadow: 0 2px 4px rgba(0,0,0,0.22), 0 4px 12px rgba(0,0,0,0.22);
        }
        .ttd-floating-btn:active { transform: translateY(0); box-shadow: 0 1px 2px rgba(0,0,0,0.18); }
        .ttd-floating-btn[data-feature="transcript"] {
          background: linear-gradient(135deg, #5b67e0 0%, #6a4ba0 100%);
        }
        .ttd-floating-btn[data-feature="video"] {
          background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        }
        .ttd-floating-btn[data-state="waiting"] {
          opacity: 0.55;
          cursor: progress;
        }
        .ttd-floating-btn .ttd-dl-arrow {
          flex: 0 0 auto;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          border-radius: 4px;
          background: rgba(255,255,255,0.22);
        }
        .ttd-floating-btn .ttd-dl-arrow svg {
          display: block;
          width: 12px;
          height: 12px;
          fill: #fff;
        }
        .ttd-floating-btn .ttd-dl-label { white-space: nowrap; }
      `;
      document.head.appendChild(style);
    }

    const widget = document.createElement('div');
    widget.id = 'ttdFloatingWidget';
    widget.innerHTML = `
      <button class="ttd-floating-btn" data-feature="transcript" data-state="waiting" type="button">
        <span class="ttd-dl-arrow">${DL_SVG}</span><span class="ttd-dl-label">Descargar transcripción</span>
      </button>
      <button class="ttd-floating-btn" data-feature="video" data-state="waiting" type="button">
        <span class="ttd-dl-arrow">${DL_SVG}</span><span class="ttd-dl-label">Descargar vídeo</span>
      </button>
    `;
    document.body.appendChild(widget);

    widget.querySelector('[data-feature="transcript"]').addEventListener('click', handleDownloadClick);
    widget.querySelector('[data-feature="video"]').addEventListener('click', handleVideoDownloadClick);

    updateFloatingWidgetState();
    return true;
  }
  function isLikelyVideoPage() {
    const loc = window.location;
    const path = (loc.pathname || '').toLowerCase();
    const search = (loc.search || '').toLowerCase();
    if (path.includes('/stream.aspx')) return true;
    if (path.includes('/embed.aspx') && /\.(mp4|m4v|mov|webm|avi|mkv)/.test(search)) return true;
    if (/^teams\./.test(loc.hostname) && window !== window.top) return true;
    return false;
  }
  function updateFloatingWidgetState() {
    const widget = document.getElementById('ttdFloatingWidget');
    if (!widget) return;

    const tBtn = widget.querySelector('[data-feature="transcript"]');
    const vBtn = widget.querySelector('[data-feature="video"]');
    const onVideoPage = isLikelyVideoPage();
    let anyVisible = false;

    if (tBtn) {
      const legacyTranscript = document.querySelector('#customDownloadTranscript');
      const show = !legacyTranscript && onVideoPage;
      tBtn.style.display = show ? '' : 'none';
      if (show) anyVisible = true;
      tBtn.setAttribute('data-state', transcriptUrl ? 'ready' : 'waiting');
      tBtn.title = transcriptUrl
        ? 'Descargar transcripción'
        : 'Transcript URL not yet captured — open the Transcript panel or click to try fetching it';
    }
    if (vBtn) {
      const legacyVideo = document.querySelector('#customDownloadVideo');
      const show = !legacyVideo && onVideoPage;
      vBtn.style.display = show ? '' : 'none';
      if (show) anyVisible = true;
      vBtn.setAttribute('data-state', videoManifestUrl ? 'ready' : 'waiting');
      vBtn.title = videoManifestUrl
        ? 'Descargar vídeo'
        : 'Video manifest URL not yet captured — start playback or wait a moment';
    }
    widget.style.display = anyVisible ? '' : 'none';
    if (anyVisible) {
      const h = widget.offsetHeight || 44;
      document.body.style.paddingTop = h + 'px';
    } else {
      document.body.style.paddingTop = '';
    }
  }

  function injectVideoDownloadButton() {
    if (document.querySelector('#customDownloadVideo')) return true;
    if (!isLikelyVideoPage()) return true;
    const commandBar = document.querySelector('.ms-CommandBar-primaryCommand');
    if (!commandBar) {
      return false;
    }
    const templateItem = commandBar.querySelector('.ms-OverflowSet-item');
    if (!templateItem) return false;
    if (!document.querySelector('#video-download-styles')) {
      const style = document.createElement('style');
      style.id = 'video-download-styles';
      style.textContent = `
        #customDownloadVideo {
          background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%) !important;
          color: white !important;
          border: none !important;
          transition: background 0.3s ease !important;
          cursor: pointer !important;
          padding: 0 8px !important;
          height: 32px !important;
          border-radius: 4px !important;
          font-size: 13px !important;
          font-weight: 600 !important;
          display: flex !important;
          align-items: center !important;
          gap: 6px !important;
        }

        #customDownloadVideo:hover {
          background: linear-gradient(135deg, #c0392b 0%, #e74c3c 100%) !important;
        }

        #customDownloadVideo:active {
          box-shadow: 0 2px 4px rgba(231, 76, 60, 0.4) !important;
        }
      `;
      document.head.appendChild(style);
    }
    const newContainer = document.createElement('div');
    newContainer.className = templateItem.className; // ms-OverflowSet-item item-XX
    newContainer.setAttribute('role', 'none');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'customDownloadVideo';
    btn.setAttribute('role', 'menuitem');
    btn.setAttribute('aria-label', 'Descargar vídeo');
    btn.setAttribute('data-is-focusable', 'true');
    btn.innerHTML = `
      <span style="display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:4px;background:rgba(255,255,255,0.22);margin-right:6px;vertical-align:middle;">
        <span style="display:inline-block;width:12px;height:12px;line-height:0;">${DL_SVG.replace('<svg', '<svg style="display:block;width:12px;height:12px;fill:#fff;"')}</span>
      </span>
      <span style="vertical-align:middle;">Descargar vídeo</span>
    `;
    btn.addEventListener('click', handleVideoDownloadClick);

    newContainer.appendChild(btn);
    commandBar.appendChild(newContainer);

    console.debug('[XULFADP] Video download button injected into command bar');
    injectTranscriptIntoCommandBar(commandBar, templateItem);

    return true;
  }
  function injectTranscriptIntoCommandBar(commandBar, templateItem) {
    if (document.querySelector('#customDownloadTranscript')) return false;
    if (!commandBar || !templateItem) return false;

    if (!document.querySelector('#transcript-cmdbar-styles')) {
      const style = document.createElement('style');
      style.id = 'transcript-cmdbar-styles';
      style.textContent = `
        #customDownloadTranscript {
          background: linear-gradient(135deg, #5b67e0 0%, #6a4ba0 100%) !important;
          color: white !important;
          border: none !important;
          transition: background 0.3s ease !important;
          cursor: pointer !important;
          padding: 0 8px !important;
          height: 32px !important;
          border-radius: 4px !important;
          font-size: 13px !important;
          font-weight: 600 !important;
          margin: 0 4px !important;
          display: inline-flex !important;
          align-items: center !important;
        }
        #customDownloadTranscript:hover {
          background: linear-gradient(135deg, #6a4ba0 0%, #5b67e0 100%) !important;
        }
      `;
      document.head.appendChild(style);
    }

    const newContainer = document.createElement('div');
    newContainer.className = templateItem.className;
    newContainer.setAttribute('role', 'none');

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'customDownloadTranscript';
    btn.setAttribute('role', 'menuitem');
    btn.setAttribute('aria-label', 'Descargar transcripción');
    btn.setAttribute('data-is-focusable', 'true');
    btn.innerHTML = `
      <span style="display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:4px;background:rgba(255,255,255,0.22);margin-right:6px;vertical-align:middle;">
        <span style="display:inline-block;width:12px;height:12px;line-height:0;">${DL_SVG.replace('<svg', '<svg style="display:block;width:12px;height:12px;fill:#fff;"')}</span>
      </span>
      <span style="vertical-align:middle;">Descargar transcripción</span>
    `;
    btn.addEventListener('click', handleDownloadClick);

    newContainer.appendChild(btn);
    commandBar.appendChild(newContainer);
    console.debug('[XULFADP] Transcript button injected into command bar');
    return true;
  }

  function handleVideoDownloadClick(event) {
    event.preventDefault();
    event.stopPropagation();

    console.log('[XULFADP] Video download button clicked');

    if (!videoManifestUrl) {
      alert('Todavía no se ha detectado el vídeo. Espera unos segundos, inicia la reproducción o actualiza la página.');
      console.error('[XULFADP] No video manifest URL available');
      return;
    }

    showVideoModal();
  }

  function getVideoFilename() {
    return getDefaultBaseName().replace(/[^a-z0-9\s]/gi, '_').trim() || 'video';
  }

  function createVideoModal() {
    const modal = document.createElement('div');
    modal.id = 'videoDownloadModal';

    const autoFilename = getVideoFilename();

    const browserFormats = [
      { id: 'video-audio', title: 'Vídeo + audio', badge: '.mp4', icon: '&#127916;' },
      { id: 'audio-m4a', title: 'Audio (M4A)', badge: '.m4a', icon: '&#127925;' },
      { id: 'video-only', title: 'Solo vídeo', badge: '.mp4', icon: '&#127910;' }
    ];

    function renderCards(formats, prefix) {
      return formats.map(f => `
        <div class="video-format-card" data-format="${f.id}" data-prefix="${prefix}">
          <div class="video-format-icon">${f.icon}</div>
          <div class="video-format-info">
            <h3>${f.title} <span class="format-badge video-badge">${f.badge}</span></h3>
          </div>
        </div>
      `).join('');
    }

    modal.innerHTML = `
      <div class="modal-content video-modal-content">
        <div class="modal-header">
          <h2>Descargar vídeo</h2>
          <button class="modal-close" id="videoModalClose">&times;</button>
        </div>

        <div class="filename-section">
          <label for="videoFilenameInput" class="filename-label">
            <span class="label-text">Nombre del archivo:</span>
          </label>
          <div class="filename-input-container">
            <input
              type="text"
              id="videoFilenameInput"
              class="filename-input"
              placeholder="Enter filename"
              value="${escapeHtml(autoFilename)}"
            />
          </div>
        </div>

        <div class="video-format-cards">
          ${renderCards(browserFormats, 'dl')}
        </div>
        <button class="browser-dl-action-btn" id="browserDlActionBtn" disabled>Select a format above</button>
        <div class="browser-download-section" id="browserDownloadSection" style="display: none; margin-top: 12px;">
          <div class="browser-dl-progress-bar-wrap">
            <div class="browser-dl-progress-bar" id="browserDlProgressBar" style="width:0%"></div>
          </div>
          <div class="browser-dl-status" id="browserDlStatus"></div>
        </div>

        <div class="video-parallel-row">
          <label for="videoParallelSelect" class="video-parallel-label">Descargas paralelas de segmentos</label>
          <select id="videoParallelSelect" class="video-parallel-select">
            ${VIDEO_CONCURRENCY_OPTIONS.map(n => `<option value="${n}"${n === videoDownloadConcurrency ? ' selected' : ''}>${n}</option>`).join('')}
          </select>
          <span class="video-parallel-hint">total in flight &mdash; higher = faster, but more risk of throttling (429s are auto-retried)</span>
        </div>

        <div class="modal-actions">
          <div class="modal-actions-buttons">
            <button class="modal-button modal-button-cancel" id="videoModalCancel">Cerrar</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    let abortController = null;
    const dlCards = modal.querySelectorAll('.video-format-card');
    const dlBtn = modal.querySelector('#browserDlActionBtn');
    let selectedBrowserFormat = null;

    dlCards.forEach(card => {
      card.addEventListener('click', () => {
        dlCards.forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        selectedBrowserFormat = card.getAttribute('data-format');
        dlBtn.disabled = false;
        dlBtn.textContent = '\u2193 Descargar';
      });
    });

    const defaultCard = modal.querySelector('.video-format-card[data-format="video-audio"]');
    if (defaultCard) {
      defaultCard.classList.add('selected');
      selectedBrowserFormat = 'video-audio';
      dlBtn.disabled = false;
      dlBtn.textContent = '\u2193 Descargar';
    }
    const parallelSel = modal.querySelector('#videoParallelSelect');
    if (parallelSel) {
      parallelSel.addEventListener('change', () => {
        const n = parseInt(parallelSel.value, 10);
        if (VIDEO_CONCURRENCY_OPTIONS.includes(n)) {
          videoDownloadConcurrency = n;
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            chrome.storage.sync.set({ videoDownloadConcurrency: n });
          }
        }
      });
    }

    dlBtn.addEventListener('click', async () => {
      if (!selectedBrowserFormat) return;

      if (abortController) {
        abortController.abort();
        return;
      }

      const filename = modal.querySelector('#videoFilenameInput').value.trim() || 'video';
      abortController = new AbortController();
      dlBtn.textContent = 'Cancelar descarga';
      dlBtn.classList.add('browser-dl-cancelling');
      dlCards.forEach(c => { c.style.pointerEvents = 'none'; c.style.opacity = '0.6'; });

      const section = modal.querySelector('#browserDownloadSection');
      const bar = modal.querySelector('#browserDlProgressBar');
      const status = modal.querySelector('#browserDlStatus');
      section.style.display = '';
      bar.className = 'browser-dl-progress-bar';
      bar.style.width = '0%';
      status.textContent = '';

      try {
        await triggerBrowserVideoDownload(
          selectedBrowserFormat, filename,
          (done, total, text) => {
            bar.style.width = (total > 0 ? Math.round((done / total) * 100) : 0) + '%';
            status.textContent = text || '';
          },
          abortController.signal
        );
        bar.style.width = '100%';
        bar.classList.add('browser-dl-complete');
        status.textContent = 'Descarga completada!';
      } catch (err) {
        if (err.name === 'AbortError') {
          status.textContent = 'Descarga cancelada.';
        } else if (err.isDrm) {
          console.error('[XULFADP] DRM-protected video — cannot download');
          status.textContent = 'Protegido con DRM: no se puede descargar.';
          bar.classList.add('browser-dl-error');
          showDrmWarning();
        } else {
          console.error('[XULFADP] Browser download error:', err);
          let msg = err.message || String(err);
          if (err.name === 'TypeError' && /failed to fetch/i.test(msg)) {
            msg = 'Browser blocked the segment fetch (cross-origin / CORS). ' +
                  'Common when viewing a video as a guest or in a tenant with strict CDN policies. ' +
                  'The native SharePoint player works because it uses the browser\'s DRM module — that path is not available to extensions.';
          }
          status.textContent = 'Error: ' + msg;
          bar.classList.add('browser-dl-error');
        }
      } finally {
        abortController = null;
        dlBtn.textContent = '\u2193 Descargar';
        dlBtn.classList.remove('browser-dl-cancelling');
        dlCards.forEach(c => { c.style.pointerEvents = ''; c.style.opacity = ''; });
      }
    });
    function closeModal() {
      if (abortController) { abortController.abort(); abortController = null; }
      modal.classList.remove('show');
    }

    modal.querySelector('#videoModalClose').addEventListener('click', closeModal);
    modal.querySelector('#videoModalCancel').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
  }

  function showVideoModal() {
    const existing = document.getElementById('videoDownloadModal');
    if (existing) existing.remove();

    createVideoModal();
    document.getElementById('videoDownloadModal').classList.add('show');
  }
  let __ttdInitDone = false;
  let __ttdWatchdogId = null;
  function initialize() {
    if (__ttdInitDone) return;
    __ttdInitDone = true;
    requestTranscriptContext();
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(['videoDownloadConcurrency'], (result) => {
        const saved = parseInt(result.videoDownloadConcurrency, 10);
        if (VIDEO_CONCURRENCY_OPTIONS.includes(saved)) videoDownloadConcurrency = saved;
      });
    }

    injectFloatingWidget();

    let transcriptDone = injectDownloadButton();
    let videoDone = injectVideoDownloadButton();
    updateFloatingWidgetState();

    if (transcriptDone && videoDone) {
      console.debug('[XULFADP] Both legacy buttons injected on initial load');
    } else {
      const observer = new MutationObserver(() => {
        if (!document.getElementById('ttdFloatingWidget')) injectFloatingWidget();

        if (!transcriptDone) transcriptDone = injectDownloadButton();
        if (!videoDone) videoDone = injectVideoDownloadButton();
        updateFloatingWidgetState();

        if (transcriptDone && videoDone) {
          console.debug('[XULFADP] Both legacy buttons injected after DOM change');
          observer.disconnect();
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });

      setTimeout(() => {
        observer.disconnect();
      }, 30000);
    }
    if (__ttdWatchdogId !== null) clearInterval(__ttdWatchdogId);
    __ttdWatchdogId = setInterval(() => {
      if (!document.getElementById('ttdFloatingWidget')) injectFloatingWidget();
      else updateFloatingWidgetState();
    }, 2000);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
  window.addEventListener('load', () => {
    setTimeout(initialize, 1000);
  });
})();
