# Ficha propuesta para Microsoft Edge Add-ons

## Nombre

XULFADP – Exportador multimedia para Edge

## Descripción corta

Guarda vídeos, audio y transcripciones disponibles para tu cuenta.

## Descripción completa

XULFADP permite exportar a tu equipo contenidos que ya puedes reproducir en
plataformas compatibles. Ofrece descarga de vídeo con audio en MP4, audio en
M4A, vídeo sin audio y transcripciones en JSON, VTT o texto agrupado.

Todo el procesamiento se realiza localmente en el navegador. La extensión no
incorpora analítica, publicidad ni servidores propios y no evita restricciones
de acceso o DRM.

XULFADP es una aplicación independiente y no está afiliada, patrocinada ni
aprobada por Microsoft.

## Finalidad única

Permitir que el usuario guarde localmente contenido multimedia y transcripciones
que ya está autorizado a reproducir.

## Justificación de permisos

- `storage`: recordar el formato seleccionado y el límite de descargas paralelas.
- Acceso a dominios compatibles: detectar manifiestos, fragmentos multimedia y
  transcripciones durante la reproducción autorizada.

## Compatibilidad

Esta edición utiliza Manifest V3 y las API de extensiones basadas en Chromium
compatibles con Microsoft Edge. No requiere servicios propios ni código remoto.

## Pendiente antes de enviar

- Añadir correo de soporte real.
- Publicar PRIVACY.md en una URL pública y registrarla en la ficha.
- Preparar capturas reales de la interfaz.
- Probar la descarga con una cuenta de prueba y facilitar instrucciones al revisor de Microsoft.
