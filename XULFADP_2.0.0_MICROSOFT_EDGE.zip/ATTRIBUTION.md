# Atribución

XULFADP 2.0 es una versión modificada e independiente basada en el proyecto
“MS Teams / SharePoint / Stream — Video & Transcript Downloader”, creado por
Brendan Gooden y distribuido bajo licencia MIT.

Proyecto original:
https://github.com/brendangooden/ms-teams-sharepoint-downloader

Modificaciones principales de esta edición:

- Identidad visual y denominación XULFADP.
- Interfaz adaptada al español.
- Documentación de privacidad y publicación.
- Juego completo de iconos para Chrome.

XULFADP no está afiliada, patrocinada ni aprobada por Microsoft Corporation.
Microsoft, Teams, SharePoint y sus respectivos logotipos y marcas pertenecen
a sus titulares.
